import {
  HomeIcon,
  ListIcon,
  MusicIcon,
  RadioIcon,
  SearchIcon,
  SmileIcon,
} from "lucide-react";
import React from "react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";

export const StartPage = (): JSX.Element => {
  // Navigation menu items data
  const discoverMenuItems = [
    { icon: <HomeIcon className="w-6 h-6" />, label: "Home", active: true },
    {
      icon: <SearchIcon className="w-6 h-6" />,
      label: "Browse",
      active: false,
    },
    { icon: <RadioIcon className="w-6 h-6" />, label: "Radio", active: false },
  ];

  const libraryMenuItems = [
    {
      icon: <ListIcon className="w-6 h-6" />,
      label: "Playlists",
      active: false,
    },
    { icon: <MusicIcon className="w-6 h-6" />, label: "Songs", active: false },
    {
      icon: <SmileIcon className="w-6 h-6" />,
      label: "Personalized picks",
      active: false,
    },
  ];

  // Contact information
  const contactInfo = {
    address: [
      "#1381, National Road 2,",
      "Phum Tuol Roka,",
      "Sangkat Chat Angre Krom, Khan Meanchey",
      "Phnom Penh, Cambodia",
    ],
    phones: ["+855 17 350 544", "+855 16 708 848", "+855 88 733 4902"],
  };

  return (
    <div className="bg-white flex flex-row justify-center w-full">
      <div className="bg-white overflow-hidden w-[1488px] h-[1004px]">
        <div className="relative w-[1440px] h-[1098px] top-px">
          <div className="absolute w-[1440px] h-[1098px] top-0 left-0">
            <img
              className="absolute w-[1184px] h-52 top-[93px] left-64"
              alt="Banner image"
              src="/image-4.png"
            />

            <header className="flex flex-wrap w-[1440px] items-center gap-[0px_24px] p-8 absolute top-0 left-0 bg-[#116c9b] border-b border-[#d9d9d9]">
              <div className="flex flex-wrap items-start justify-end gap-[8px_8px] relative flex-1 grow" />

              <div className="flex w-[178px] items-center gap-3 relative">
                <Button
                  variant="outline"
                  className="flex-1 bg-[#e3e3e3] text-[#1e1e1e] border-[#767676] rounded-lg font-single-line-body-base"
                >
                  Sign in
                </Button>

                <Button className="flex-1 bg-[#2c2c2c] text-neutral-100 rounded-lg font-single-line-body-base">
                  Register
                </Button>
              </div>
            </header>

            <Card className="flex flex-col w-[1184px] h-[350px] items-center gap-8 px-6 py-40 absolute top-[304px] left-64 bg-neutral-100 border-none rounded-none" />

            <div className="flex flex-col w-[1136px] items-center gap-2 absolute top-[402px] left-[248px]">
              <h1 className="relative w-fit mt-[-1.00px] font-title-page font-[number:var(--title-page-font-weight)] text-[#116c9b] text-[length:var(--title-page-font-size)] text-center tracking-[var(--title-page-letter-spacing)] leading-[var(--title-page-line-height)] whitespace-nowrap [font-style:var(--title-page-font-style)]">
                Mekong Inclusive Ventures
              </h1>

              <p className="relative self-stretch font-subheading font-[number:var(--subheading-font-weight)] text-[#757575] text-[length:var(--subheading-font-size)] text-center tracking-[var(--subheading-letter-spacing)] leading-[var(--subheading-line-height)] [font-style:var(--subheading-font-style)]">
                Your central hub for managing your venture&apos;s growth — from
                diagnostics to readiness,
                <br />
                GEDSI compliance, and capital facilitation — all in one place.
              </p>
            </div>

            <img
              className="absolute w-[76px] h-20 top-3.5 left-[33px] object-cover"
              alt="MIV Logo"
              src="/image-2.png"
            />

            <div className="flex w-[51px] h-[54px] items-center justify-center gap-2 p-3 absolute top-[113px] left-[1373px] rounded-lg overflow-hidden [background:url(..//button.png)_50%_50%_/_cover]">
              <span className="relative w-fit font-single-line-body-base font-[number:var(--single-line-body-base-font-weight)] text-neutral-100 text-[length:var(--single-line-body-base-font-size)] tracking-[var(--single-line-body-base-letter-spacing)] leading-[var(--single-line-body-base-line-height)] whitespace-nowrap [font-style:var(--single-line-body-base-font-style)]">
                {""}
              </span>
            </div>

            {/* Sidebar Navigation */}
            <aside className="absolute w-64 h-[1004px] top-[94px] left-0 bg-white border-r border-[#dfdfdf]">
              <nav className="flex flex-col w-60 items-start gap-1 absolute top-[78px] left-2">
                <div className="flex h-10 items-center gap-4 px-4 py-0 relative self-stretch w-full rounded-lg">
                  <h2 className="relative w-52 h-6 [font-family:'Inter',Helvetica] font-semibold text-black text-base tracking-[0] leading-6 whitespace-nowrap">
                    Discover
                  </h2>
                </div>

                {discoverMenuItems.map((item, index) => (
                  <Button
                    key={`discover-${index}`}
                    variant="ghost"
                    className={`flex h-10 items-center gap-4 px-4 py-0 justify-start relative self-stretch w-full rounded-lg ${
                      item.active ? "bg-[#f7f7f7]" : "bg-white"
                    }`}
                  >
                    {item.icon}
                    <span className="relative flex-1 font-small-text font-[number:var(--small-text-font-weight)] text-black text-[length:var(--small-text-font-size)] tracking-[var(--small-text-letter-spacing)] leading-[var(--small-text-line-height)] [font-style:var(--small-text-font-style)] text-left">
                      {item.label}
                    </span>
                  </Button>
                ))}
              </nav>

              <nav className="flex flex-col w-60 items-start gap-2 absolute top-[274px] left-2">
                <div className="flex items-center gap-2 px-4 py-0 relative self-stretch w-full flex-[0_0_auto]">
                  <h2 className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-semibold text-black text-base tracking-[0] leading-6">
                    Library
                  </h2>
                </div>

                {libraryMenuItems.map((item, index) => (
                  <Button
                    key={`library-${index}`}
                    variant="ghost"
                    className={`flex h-10 items-center gap-4 px-4 py-0 justify-start relative self-stretch w-full rounded-lg ${
                      item.active ? "bg-[#f7f7f7]" : "bg-white"
                    }`}
                  >
                    {item.icon}
                    <span className="relative flex-1 font-small-text font-[number:var(--small-text-font-weight)] text-black text-[length:var(--small-text-font-size)] tracking-[var(--small-text-letter-spacing)] leading-[var(--small-text-line-height)] [font-style:var(--small-text-font-style)] text-left">
                      {item.label}
                    </span>
                  </Button>
                ))}
              </nav>
            </aside>
          </div>

          {/* Social Media Section */}
          <div className="absolute w-[271px] h-[130px] top-[702px] left-[1042px]">
            <div className="inline-flex items-center justify-center gap-2 p-3 absolute top-[86px] left-[83px] rounded-[32px] [background:url(..//icon-button.png)_50%_50%_/_cover]" />
            <div className="flex w-12 h-11 items-center justify-center gap-2 p-3 absolute top-[86px] left-[143px] rounded-[32px] [background:url(..//icon-button-1.png)_50%_50%_/_cover]" />
            <p className="absolute w-[271px] h-[116px] top-0 left-0 font-body-base font-[number:var(--body-base-font-weight)] text-black text-[length:var(--body-base-font-size)] text-center tracking-[var(--body-base-letter-spacing)] leading-[var(--body-base-line-height)] [font-style:var(--body-base-font-style)]">
              Follow MIV on our socials
            </p>
          </div>

          {/* MIV Logo in Footer */}
          <img
            className="absolute w-[210px] h-[122px] top-[740px] left-[381px] object-cover"
            alt="MIV Logo"
            src="/image-3.png"
          />

          {/* Contact Information */}
          <Card className="absolute w-[283px] h-[271px] top-[663px] left-[710px] border-none bg-transparent">
            <CardContent className="p-0">
              <div className="[font-family:'Inter',Helvetica] font-normal text-black text-base text-center tracking-[0] leading-4">
                <p className="leading-[22.4px]">
                  Contact Details
                  <br />
                  {contactInfo.address.map((line, index) => (
                    <React.Fragment key={`address-${index}`}>
                      {line}
                      <br />
                    </React.Fragment>
                  ))}
                  <br />
                  Phone Number
                  <br />
                </p>

                <p className="font-[number:var(--body-base-font-weight)] leading-[var(--body-base-line-height)] font-body-base [font-style:var(--body-base-font-style)] tracking-[var(--body-base-letter-spacing)] text-[length:var(--body-base-font-size)]">
                  {contactInfo.phones.map((phone, index) => (
                    <React.Fragment key={`phone-${index}`}>
                      {phone}
                      <br />
                    </React.Fragment>
                  ))}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
