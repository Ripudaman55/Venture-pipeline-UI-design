import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { StartPage } from "./screens/StartPage";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <StartPage />
  </StrictMode>,
);
